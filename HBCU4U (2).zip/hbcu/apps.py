from django.apps import AppConfig


class HbcuConfig(AppConfig):
    name = 'hbcu'
